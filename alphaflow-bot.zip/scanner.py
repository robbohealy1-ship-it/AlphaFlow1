import os, asyncio
from typing import List, Dict, Any, Optional
import httpx, pandas as pd
import pandas_ta as ta
from dateutil import tz

API_BASE = "https://api.binance.com"
SERVICE_URL = os.getenv("SERVICE_URL")  # e.g. https://alphaflow-worker.onrender.com
TIER_FOR_FREE = "free"
TIER_FOR_PRO  = "pro"

async def fetch_klines(symbol: str, interval: str = "15m", limit: int = 300) -> pd.DataFrame:
    url = f"{API_BASE}/api/v3/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        data = r.json()
    cols = ["open_time","open","high","low","close","volume","close_time","qav","ntrades","tbbav","tbqav","ignore"]
    df = pd.DataFrame(data, columns=cols)
    for c in ("open","high","low","close","volume"):
        df[c] = df[c].astype(float)
    df["time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
    return df

async def fetch_klines_htf(symbol: str, interval: str = "4h", limit: int = 200) -> pd.DataFrame:
    return await fetch_klines(symbol, interval, limit)

def compute_indicators(df: pd.DataFrame) -> Dict[str, Any]:
    tech: Dict[str, Any] = {}
    df["ema20"] = ta.ema(df["close"], length=20)
    df["ema50"] = ta.ema(df["close"], length=50)
    df["atr14"] = ta.atr(high=df["high"], low=df["low"], close=df["close"], length=14)
    df["rsi14"] = ta.rsi(df["close"], length=14)
    last = df.iloc[-1]
    tech["ema_fast"] = float(last["ema20"]) if pd.notna(last["ema20"]) else None
    tech["ema_slow"] = float(last["ema50"]) if pd.notna(last["ema50"]) else None
    tech["atr"]      = float(last["atr14"]) if pd.notna(last["atr14"]) else None
    tech["rsi"]      = float(last["rsi14"]) if pd.notna(last["rsi14"]) else None
    return tech

def bias_from_htf(htf: pd.DataFrame) -> str:
    htf["ema20"] = ta.ema(htf["close"], length=20)
    htf["ema50"] = ta.ema(htf["close"], length=50)
    l = htf.iloc[-1]
    if pd.notna(l["ema20"]) and pd.notna(l["ema50"]):
        return "BUY" if l["ema20"] > l["ema50"] else "SELL"
    return "BUY"

def rule_signal(symbol: str, df15: pd.DataFrame, df4h: pd.DataFrame) -> Optional[Dict[str, Any]]:
    bias = bias_from_htf(df4h)
    tech = compute_indicators(df15)
    if not all(k in tech for k in ("ema_fast","ema_slow","atr","rsi")):
        return None
    side = None
    price = float(df15["close"].iloc[-1])
    if bias == "BUY" and tech["ema_fast"] and tech["ema_slow"] and tech["ema_fast"] > tech["ema_slow"] and tech["rsi"] and tech["rsi"] >= 55:
        side = "BUY"
    elif bias == "SELL" and tech["ema_fast"] and tech["ema_slow"] and tech["ema_fast"] < tech["ema_slow"] and tech["rsi"] and tech["rsi"] <= 45:
        side = "SELL"
    if not side:
        return None
    atr = tech["atr"] or 0.0
    if atr <= 0: return None
    d = 1 if side == "BUY" else -1
    stop = price - d * (1.5 * atr)
    risk = abs(price - stop)
    tp1  = price + d * (1.0 * risk)
    tp2  = price + d * (2.0 * risk)
    payload = {
        "symbol": symbol,
        "timeframe": "15m",
        "side": side,
        "price": price,
        "stop": stop,
        "tp1": tp1,
        "tp2": tp2,
        "reason": f"{side} with 4H bias • EMA20/50 alignment • RSI filter",
        "technicals": {
            "ema_fast": tech["ema_fast"],
            "ema_slow": tech["ema_slow"],
            "rsi": tech["rsi"],
            "atr": tech["atr"],
        },
    }
    return payload

async def scan_once(symbols: List[str]) -> List[Dict[str, Any]]:
    setups: List[Dict[str, Any]] = []
    for sym in symbols:
        try:
            df15 = await fetch_klines(sym, "15m", 300)
            df4h = await fetch_klines_htf(sym, "4h", 300)
            setup = rule_signal(sym, df15, df4h)
            if setup: setups.append(setup)
        except Exception as e:
            print("scan error", sym, e)
    return setups

async def post_signal(tier: str, payload: Dict[str, Any], source: str = "scanner"):
    url = f"{SERVICE_URL.rstrip('/')}/send"
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(url, json={"tier": tier, "source": source, "payload": payload})
        print("post", tier, payload["symbol"], r.status_code)

async def main():
    if not SERVICE_URL:
        raise SystemExit("Set SERVICE_URL env to your web service URL (e.g. https://alphaflow-worker.onrender.com)")
    with open("symbols_binance.txt") as f:
        symbols = [s.strip() for s in f if s.strip()]
    setups = await scan_once(symbols)
    for p in setups:
        await post_signal(TIER_FOR_FREE, p, source="scanner-15m")
        await post_signal(TIER_FOR_PRO, p, source="scanner-15m")
    print(f"done. sent {len(setups)} setups")

if __name__ == "__main__":
    asyncio.run(main())
